%% bellhop生成音频
% 主要功能:
%   1. 加载BELLHOP仿真结果（两个不同的环境）
%   2. 应用声场传播模型到两个不同位置的音频数据
%   3. 输出bellhop计算后的音频，用来验证对比
%

%% 准备条件
oriDataPath = "D:\data_gen\shipsear_5s_16k";                % 原始数据文件夹路径
ocnDataPath = "D:\data_gen\Verify\compare";    % 扩充数据文件夹路径
envConfig1 = 'Pos1Azi1freq100Hz';   % 定义两个不同的环境配置   
envConfig2 = 'Pos1Azi1freq100Hz_1';    
selectedFileA = 'D:\data_gen\shipsear_5s_16k\0\0_1_5.wav';    % 随机选择一个音频文件
selectedFileB = 'D:\data_gen\shipsear_5s_16k\1\1_0_7.wav';

bellhop(envConfig1)     % 加载两个环境的BELLHOP仿真结果
[Arr1, Pos1] = read_arrivals_asc([envConfig1 '.arr']);      % Arr1/Pos1: 第一个环境的延迟、幅度、距离和深度信息
bellhop(envConfig2)  
[Arr2, Pos2] = read_arrivals_asc([envConfig2 '.arr']);      % Arr2/Pos2: 第二个环境的延迟、幅度、距离和深度信息

%% 生成组合的音频文件
fprintf('Processing combination ...\n');
% 读取选中的音频文件
[y1, fs1] = audioread(selectedFileA);
[y2, fs2] = audioread(selectedFileB);
if fs1 ~= fs2  % 确保采样率相同
    error('The two selected audio files have different sampling rates');
end
fs = fs1;
% 对输入音频进行归一化处理，使两个原始音频信号的幅度范围保持一致 
y1 = funNorm(y1);
y2 = funNorm(y2);
% 随机分配位置索引
k1 = randi(length(Pos1.r.r));   % A音频的距离索引 (第一个环境)
n1 = randi(length(Pos1.r.z));   % 深度索引
k2 = randi(length(Pos2.r.r));   % B音频的距离索引 (第二个环境) 
n2 = randi(length(Pos2.r.z));   % 深度索引
% 提取音频的传播参数
Arr_A1 = double(Arr1(k1, 1, n1).A);     % 振幅归一化
Arr_TAU1 = double(Arr1(k1, 1, n1).delay - min(Arr1(k1, 1, n1).delay));  % 相对延迟
Arr_A2 = double(Arr2(k2, 1, n2).A);     
Arr_TAU2 = double(Arr2(k2, 1, n2).delay - min(Arr2(k2, 1, n2).delay)); 
y_out1 = funMulti_Eff(y1, fs, Arr_A1, Arr_TAU1);  %  应用海洋声传播模型
y_out2 = funMulti_Eff(y2, fs, Arr_A2, Arr_TAU2);  % B音频在指定环境下的传播结果  
outputFileName0 = 'y_out1.wav';     % 生成输出文件名（包含组合编号）
outputFilePath0 = fullfile(ocnDataPath, outputFileName0);
outputFileName1 = 'y_out2.wav';     % 生成输出文件名（包含组合编号）
outputFilePath1 = fullfile(ocnDataPath, outputFileName1);

audiowrite(outputFilePath0, y_out1, fs);     % 保存叠加后的音频文件
audiowrite(outputFilePath1, y_out2, fs);     % 保存叠加后的音频文件

fprintf('completed. Output file: %s and %s\n', outputFileName0, outputFileName1);


