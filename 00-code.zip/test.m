clc;

bellhop Pos1Azi1freq100Hz_1;
[ Arr, Pos ] = read_arrivals_asc( 'Pos1Azi1freq100Hz_1.arr' );
plotarr(  'Pos1Azi1freq100Hz_1.arr', 1, 1, 1 )

bellhop Pos1Azi1freq100Hz;
figure;
hold on;

plotbty Pos1Azi1freq100Hz.bty%% 生成海底模型

bellhop Pos1Azi1freq100Hz;
plotshd('Pos1Azi1freq100Hz.shd');
grid on;

plotssp('Pos1Azi1freq100Hz_1');%% 生成声速剖面图
plotray('Pos1Azi1freq100Hz_1');%% 