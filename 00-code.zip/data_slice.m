%% 音频切割处理模块
% 将音频文件分割为固定时长的块
%
% 参数:
%   input_file: 输入音频文件路径
%   output_dir: 输出目录
%   chunk_duration: 每个块的时长（秒）
input_file = 'D:\data_gen\data_process\DeepShip-main\DeepShip-main\Tug\9.wav';
output_dir = 'D:\data_gen\data_process\post_process\1';
chunk_duration = 5;
[y, fs] = audioread(input_file);     % 读取音频文件
fprintf('%d',fs);    
total_samples = length(y);      % 计算样本数
chunk_samples = round(5 * fs);

if ~exist(output_dir, 'dir')    % 创建输出目录
    mkdir(output_dir);
end

chunk_count = 0;    % 分割音频
for i = 1:chunk_samples:total_samples
    end_idx = min(i + chunk_samples - 1, total_samples);
    chunk = y(i:end_idx);
    
    % 填充到固定长度
    if length(chunk) < chunk_samples
        chunk = [chunk; zeros(chunk_samples - length(chunk), 1)];
    end
    
    % 生成输出文件名
    chunk_count = chunk_count + 1;
    output_name = sprintf('%03d.wav', chunk_count);
    output_path = fullfile(output_dir,output_name);

    % 保存音频块
    audiowrite(output_path, chunk, fs);
    fprintf('已保存: %s\n', output_name);
end

fprintf('总共生成 %d 个音频块\n', chunk_count);